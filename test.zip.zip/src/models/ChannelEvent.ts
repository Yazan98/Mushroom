export enum ChannelEvent {
  BACKEND,
  ANDROID,
  GENERAL,
}

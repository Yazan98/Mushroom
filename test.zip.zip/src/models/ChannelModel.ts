export class ChannelModel {
  constructor(public id: string, public name: string) {
    this.id = id;
    this.name = name;
  }
}

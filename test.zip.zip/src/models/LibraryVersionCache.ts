export interface LibraryVersionCache {
  name: string;
  version: string;
}
